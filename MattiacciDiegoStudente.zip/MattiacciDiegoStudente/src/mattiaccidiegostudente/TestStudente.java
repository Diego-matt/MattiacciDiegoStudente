package mattiaccidiegostudente;

import java.util.*;

public class TestStudente {

     public void avvia() {
        Scanner s = new Scanner(System.in);

        //primo studente
        System.out.println("Inserisci nome primo studente: ");
        String nome = s.nextLine();
        System.out.println("Inserisci cognome primo studente: ");
        String cognome = s.nextLine();
        System.out.println("Inserisci anno: ");
        int anno = s.nextInt();
        s.nextLine();
        System.out.println("Inserisci indirizzo: ");
        String indirizzo= s.nextLine();
        System.out.println("Inserisci sezione: ");
        String sezione = s.nextLine();
        System.out.println("Inserisci numero materie: ");
        int nMaterie = s.nextInt();

        Studente s1 = new Studente(nome, cognome, anno, indirizzo, sezione, nMaterie);

        for (int i = 0; i < nMaterie; i++) {
            System.out.println("Inserisci voto: ");
            int v = s.nextInt();
            s1.inserisciVoto(v);
        }
        s.nextLine();

        // secondo studente
        System.out.println("Inserisci nome secondo studente: ");
        String nome2 = s.nextLine();
        System.out.println("Inserisci cognome secondo studente: ");
        String cognome2 = s.nextLine();
        System.out.println("Inserisci anno: ");
        int anno2 = s.nextInt();
        s.nextLine();
        System.out.println("Inserisci indirizzo: ");
        String indirizzo2 = s.nextLine();
        System.out.println("Inserisci sezione: ");
        String sezione2 = s.nextLine();
        System.out.println("Inserisci numero materie: ");
        int nMaterie2 = s.nextInt();

        Studente s2 = new Studente(nome2, cognome2, anno2, indirizzo2, sezione2, nMaterie2);

        for (int i = 0; i < nMaterie2; i++) {
            System.out.println("Inserisci voto: ");
            int v = s.nextInt();
            s2.inserisciVoto(v);
        }

        // primo studente informazioni
        System.out.println(s1.toString());
        System.out.println("Media: " + s1.calcolaMedia());
        System.out.println("Voto massimo: " + s1.votoMax());
        System.out.println("Voto minimo: " + s1.votoMin());
        System.out.println("Insufficienze: " + s1.contaInsuff());
        System.out.println("Media sufficiente: " + s1.MediaSufficiente());

        //secondo studente informazioni
        System.out.println(s2.toString());
        System.out.println("Media: " + s2.calcolaMedia());
        System.out.println("Voto massimo: " + s2.votoMax());
        System.out.println("Voto minimo: " + s2.votoMin());
        System.out.println("Insufficienze: " + s2.contaInsuff());
        System.out.println("Media sufficiente: " + s2.MediaSufficiente());

     
 

    
        if (s1.calcolaMedia() > s2.calcolaMedia()) {
            System.out.println("Lo studente con la media più alta è: " + s1.getNome() + " " + s1.getCognome() + " (" + s1.calcolaMedia() + ")");
        } else if (s2.calcolaMedia() > s1.calcolaMedia()) {
            System.out.println("Lo studente con la media piu alta e: " + s2.getNome() + " " + s2.getCognome() + " (" + s2.calcolaMedia() + ")");
        } else {
            System.out.println("I due studenti hanno la stessa media (parità: " + s1.calcolaMedia() + ").");
        }

    }
}
