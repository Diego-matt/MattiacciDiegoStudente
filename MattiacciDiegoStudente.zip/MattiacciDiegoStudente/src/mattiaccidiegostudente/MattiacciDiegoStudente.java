package mattiaccidiegostudente;

public class MattiacciDiegoStudente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TestStudente ts = new TestStudente();
        ts.avvia();
    }
}
