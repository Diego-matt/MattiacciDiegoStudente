package mattiaccidiegostudente;

public class Studente {

    private String nome;
    private String cognome;
    private int anno;
    private String indirizzo;
    private String sezione;
    private int nMaterie;
    private int[] votiFinali;

    public Studente(String nome, String cognome, int anno, String indirizzo, String sezione, int nMaterie) {
        this.nome = nome;
        this.cognome = cognome;
        this.anno = anno;
        this.indirizzo = indirizzo;
        this.sezione = sezione;
        this.nMaterie = nMaterie;
        this.votiFinali = new int[nMaterie];
    }

    public String getNome() {
        return nome;
    }

    public String getCognome() {
        return cognome;
    }

    public int getAnno() {
        return anno;
    }

    public String getIndirizzo() {
        return indirizzo;
    }

    public String getSezione() {
        return sezione;
    }

    public int getnMaterie() {
        return nMaterie;
    }

    public int[] getVotiFinali() {
        return votiFinali;
    }

    public double calcolaMedia() {
        int somma = 0;
        int numeroVoti = 0;

        for (int i = 0; i < nMaterie; i++) {
            if (votiFinali[i] != 0) {
                somma = somma + votiFinali[i];
                numeroVoti++;
            }
        }

        if (numeroVoti == 0) {
            return 0.0;
        }
        return (double) somma / numeroVoti;
    }

    public int inserisciVoto(int v) {
        if (v < 1 || v > 10) {
            return -1;
        }

        for (int i = 0; i < nMaterie; i++) {
            if (votiFinali[i] == 0) {
                votiFinali[i] = v;
                return 1;
            }
        }

        return 0;
    }

    public int contaInsuff() {
        int c = 0;
        for (int i = 0; i < votiFinali.length; i++) {
            if (votiFinali[i] < 6 && votiFinali[i] != 0) {
                c++;
            }
        }
        return c;
    }

    public int votoMax() {
        int max = 0;
        for (int i = 0; i < votiFinali.length; i++) {
            if (votiFinali[i] != 0 && votiFinali[i] > max) {
                max = votiFinali[i];
            }
        }
        return max;
    }

    public int votoMin() {
        int min = 11;
        boolean trovato = false;
        for (int i = 0; i < votiFinali.length; i++) {
            if (votiFinali[i] != 0 && votiFinali[i] < min) {
                min = votiFinali[i];
                trovato = true;
            }
        }
        if (!trovato) {
            return 0;
        }
        return min;
    }

    public boolean MediaSufficiente() {
        if (calcolaMedia() >= 6) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String toString() {
        return "nome=" + nome + ", cognome=" + cognome + ", anno=" + anno + ", indirizzo=" + indirizzo + ", sezione=" + sezione + ", nMaterie=" + nMaterie ;
    }
}
